﻿#!/usr/bin/env python

__license__ = "GPLv3"
__version__ = "3.0.0"
__author__ = "tzagim"

from resources.lib.plugin import PopCornTimeAddon

if __name__ == '__main__':
    pct = PopCornTimeAddon()
    pct.run()
